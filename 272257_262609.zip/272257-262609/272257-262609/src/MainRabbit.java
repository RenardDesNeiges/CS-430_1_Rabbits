public class MainRabbit {
    //Main method for the Rabbit Class
    public static void main(String[] args){
        
    	RabbitsGrassSimulationModel.main(args);

    } 

}
